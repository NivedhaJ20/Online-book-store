package pro;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class BookStore {
    private Map<String, Book> books;

    public BookStore() {
        books = new HashMap<>();
    }

    public void addBook(String title, int stock) {
        Book book = new Book(title, stock);
        books.put(title, book);
    }

    public boolean isBookAvailable(String title, int quantity) {
        Book book = books.get(title);
        if (book != null && book.getStock() >= quantity) {
            return true;
        }
        return false;
    }

    public void processOrder(String title, int quantity) {
        Book book = books.get(title);
        if (book != null && book.getStock() >= quantity) {
            book.decreaseStock(quantity);
            System.out.println("Order placed successfully.");
        } else {
            System.out.println("Sorry, the book is not available in the requested quantity.");
        }
    }

    public static void main(String[] args) {
        BookStore bookstore = new BookStore();

        // Add some sample books to the bookstore with initial stock
        bookstore.addBook("Books", 10);
        bookstore.addBook("abc", 5);
        bookstore.addBook("def", 3);

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Check Stock Availability");
            System.out.println("2. Place Order");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter the book title: ");
                    String title = scanner.next();
                    System.out.print("Enter the quantity: ");
                    int quantity = scanner.nextInt();
                    boolean isAvailable = bookstore.isBookAvailable(title, quantity);
                    if (isAvailable) {
                        System.out.println("The book is available in the requested quantity.");
                    } else {
                        System.out.println("Sorry, the book is not available in the requested quantity.");
                    }
                    break;
                case 2:
                    System.out.print("Enter the book title: ");
                    title = scanner.next();
                    System.out.print("Enter the quantity: ");
                    quantity = scanner.nextInt();
                    bookstore.processOrder(title, quantity);
                    break;
                case 3:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
